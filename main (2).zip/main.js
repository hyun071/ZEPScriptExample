let spartan = App.loadSpritesheet('spartan.png', 64, 96, {
    left: [0, 1, 2, 3],
    up: [0],
    down: [0],
    right: [0,1,2,3]
}, 8); 

App.onJoinPlayer.Add(function(player){

    /** 접속시 뜨는 메세지 */
    App.showCenterLabel("Hello Word !")

    /** 이동속도 */
    player.moveSpeed = 300;

    /** 캐릭터 위 이름 (무조건 이걸로 뜸) */
    // player.title = "히횬";
    
    /** 캐릭터 위 이름 랜덤변경 */
    // let mbtis = ["FNFP", "ESTJ", "INFP", "INTP"];
    // let nth = Math.floor(Math.random() * mbtis.lenth);  /** Math.floor: 정수 */
    // player.title = mbtis[nth];
    
    player.sprite = spartan;
    player.sendUpdated();
})