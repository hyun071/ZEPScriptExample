
// 배포 : ZEP 홈페이지> 로그인> 이름> 나의앱> 압축한거넣기


/** (1) 플레이어기본정보 */
App.onJoinPlayer.Add(function (player) {

    /** 접속시 뜨는 메세지 */
    App.showCenterLabel("Hello Word !")

    /** 이동속도 */
    player.moveSpeed = 300;

    /** 캐릭터 위 이름 (무조건 이걸로 뜸) */
    // player.title = "히횬";

    /** 캐릭터 위 이름 랜덤변경 */
    // let mbtis = ["FNFP", "ESTJ", "INFP", "INTP"];
    // let nth = Math.floor(Math.random() * mbtis.lenth);  /** Math.floor: 정수 */
    // player.title = mbtis[nth];

    /** 캐릭터 이미지 변경 (좌, 우만 바꿈) */
    player.sprite = spartan;

    player.sendUpdated();
})


/** (2) 캐릭터 이미지 변경 (좌, 우만 바꿈) */
// let spartan = App.loadSpritesheet('spartan.png', 64, 96, {
// left: [0, 1, 2, 3],
// up: [0],
// down: [0],
// right: [0,1,2,3]
// }, 8); 


/** (3) 채팅창에 입력한 것을 화면에 띄우기 */
App.onsay.Add(function (player, text) {
    App.showCenterLabel(text);
})